package com.example.mediaplayer_124;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button play, forward, rewind, pause, stop, restart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        play=findViewById(R.id.play);
        forward=findViewById(R.id.forward);
        rewind=findViewById(R.id.rewind);
        pause=findViewById(R.id.pause);
        stop=findViewById(R.id.stop);
        restart=findViewById(R.id.restart);
        MediaPlayer mediaPlayer ;
        TextView t1=findViewById(R.id.songname);
        int starttime = 0 ;
        final int[] stopttime = {0};
        int forwardtime = 5000 ;
        int backwardtime = 5000 ;
        mediaPlayer=MediaPlayer.create(this, R.raw.t);
        t1.setText("t.mp3");
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Playing Media now", Toast.LENGTH_SHORT).show();
                        mediaPlayer.start();
            }
        });
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            mediaPlayer.stop();
            }
        });
        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int currentpos = mediaPlayer.getCurrentPosition() ;
                if((currentpos-currentpos) <= (stopttime[0] = mediaPlayer.getDuration())){ mediaPlayer.seekTo(currentpos-currentpos);
                }
            }
        });
        forward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int currentpos = mediaPlayer.getCurrentPosition() ;
                if((currentpos+forwardtime) <= (stopttime[0] = mediaPlayer.getDuration())){ mediaPlayer.seekTo(currentpos+forwardtime);
                }
            }
        });
        pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mediaPlayer.pause();
            }
        });
        rewind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int currentpos = mediaPlayer.getCurrentPosition() ;
                if((currentpos-backwardtime) <= (stopttime[0] = mediaPlayer.getDuration())){ mediaPlayer.seekTo(currentpos-backwardtime);
                }
            }
        });


    }
}
